package primark.esb.jtest.demo.test;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import primark.esb.jtest.demo.java.Constants;
import primark.esb.jtest.demo.java.FileUtils_k;

public class FileUtilsExc_kTest {
	public static final Logger LOGGER = Logger.getLogger(FileUtilsExc_kTest.class.getName());

	List<String> connectorFolders = ImmutableList.of("Test1_k", "TestAud_k", "TestExc_k");
	String exception = "EXCEPTION";
	String e_name;

	@Test
	public void testExceptionFiles() {
		String e_path = new File("").getAbsolutePath().replace('\\', '/') + Constants.RECORD_PATH
				+ "/FileTest_K/TestExc_k/";

		Iterable<File> e_listFiles = FileUtils_k.listFiles(new File(e_path));

		for (File file : e_listFiles) {
			// String ext1 = FilenameUtils.getExtension(file);
			// assertTrue(file.getName(),
			// connectorFiles.contains(file.getName()));
			e_name = file.getName();
			assertTrue(file.getName(), e_name.contains(exception));
		}
	}
}