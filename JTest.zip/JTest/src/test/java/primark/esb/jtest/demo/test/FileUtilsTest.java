package primark.esb.jtest.demo.test;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.List;

import primark.esb.jtest.demo.java.FileUtils;
import org.apache.log4j.Logger;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import primark.esb.jtest.demo.java.Constants;

public class FileUtilsTest {
	public static final Logger LOGGER = Logger.getLogger(FileUtilsTest.class.getName());
	
	List<String> connectorFolders = ImmutableList.of("a001TestMQ", "a002ElasticGet");
	List<String> connectorFiles = ImmutableList.of("CustomerBatch.xml", "CustomerBatch2.xml");
	

	@Test
	public void testListFolders(){
		String path = new File("").getAbsolutePath().replace('\\', '/') + Constants.RECORD_PATH + "/FileUtilsTest";
		Iterable<File> listFolders = FileUtils.listFolders(new File(path));
		
		for (File file : listFolders) {
			assertTrue(file.getName(), connectorFolders.contains(file.getName()));
		}
	}
	
	@Test
	public void testListFiles(){
		String path = new File("").getAbsolutePath().replace('\\', '/') + Constants.RECORD_PATH + "/FileUtilsTest/a001TestMQ/MQ@TEST.TRIGGER.@ENV@";
		Iterable<File> listFiles = FileUtils.listFiles(new File(path));
		
		for (File file : listFiles) {
			assertTrue(file.getName(), connectorFiles.contains(file.getName()));
		}
	}
}
