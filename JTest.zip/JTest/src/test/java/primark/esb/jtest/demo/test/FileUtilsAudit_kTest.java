package primark.esb.jtest.demo.test;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import primark.esb.jtest.demo.java.Constants;
import primark.esb.jtest.demo.java.FileUtils_k;

public class FileUtilsAudit_kTest {
	public static final Logger LOGGER = Logger.getLogger(FileUtilsAudit_kTest.class.getName());

	List<String> connectorFolders = ImmutableList.of("Test1_k", "TestAud_k", "TestExc_k");
	String audit = "AUDIT";
	String a_name;

	@Test
	public void testAuditFiles() {
		String a_path = new File("").getAbsolutePath().replace('\\', '/') + Constants.RECORD_PATH
				+ "/FileTest_K/TestAud_k/";

		Iterable<File> a_listFiles = FileUtils_k.listFiles(new File(a_path));

		for (File file : a_listFiles) {
			// String ext1 = FilenameUtils.getExtension(file);
			// assertTrue(file.getName(),
			// connectorFiles.contains(file.getName()));
			a_name = file.getName();
			assertTrue(file.getName(), a_name.contains(audit));
			// assertFalse(file.getName(), a_name.contains(exception));
		}
	}
}