package primark.esb.jtest.demo.test;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import primark.esb.jtest.demo.java.Constants;
import primark.esb.jtest.demo.java.FileUtils_k;

public class FileUtils_kTest {
	public static final Logger LOGGER = Logger.getLogger(FileUtils_kTest.class.getName());

	List<String> connectorFolders = ImmutableList.of("Test1_k", "TestAud_k", "TestExc_k");

	// List<String> connectorFiles = ImmutableList.of("a.xml", "b.xml",
	// "c.xml");
	String connectorFiles = "xml";

	@Test
	public void testListFolders() {
		String path = new File("").getAbsolutePath().replace('\\', '/') + Constants.RECORD_PATH + "/FileTest_K";
		Iterable<File> listFolders = FileUtils_k.listFolders(new File(path));

		for (File file : listFolders) {
			assertTrue(file.getName(), connectorFolders.contains(file.getName()));
		}
	}

	@Test
	public void testXMLFiles() {
		String path = new File("").getAbsolutePath().replace('\\', '/') + Constants.RECORD_PATH
				+ "/FileTest_K/Test1_k/";

		Iterable<File> listFiles = FileUtils_k.listFiles(new File(path));

		for (File file : listFiles) {
			// String ext1 = FilenameUtils.getExtension(file);
			// assertTrue(file.getName(),
			// connectorFiles.contains(file.getName()));
			assertTrue(getFileExtension(file), connectorFiles.contains(getFileExtension(file)));
		}
	}

	private String getFileExtension(File file) {
		String name = file.getName();
		try {
			return name.substring(name.lastIndexOf(".") + 1);
		} catch (Exception e) {
			return "";
		}
	}
}
