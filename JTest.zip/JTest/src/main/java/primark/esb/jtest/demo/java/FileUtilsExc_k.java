package primark.esb.jtest.demo.java;

import java.io.File;

import org.apache.log4j.Logger;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.io.Files;

public class FileUtilsExc_k {

	public static final Logger LOGGER = Logger.getLogger(FileUtilsExc_k.class.getName());

	public static Iterable<File> listFolders(File root) {
		return Iterables.filter(Files.fileTreeTraverser().children(root), new Predicate<File>() {
			@Override
			public boolean apply(File input) {
				return input.isDirectory();
			}
		});
	}

	public static Iterable<File> listFiles(File root) {
		return Iterables.filter(Files.fileTreeTraverser().children(root), new Predicate<File>() {
			@Override
			public boolean apply(File input) {
				return input.isFile();
			}
		});

	}

}
