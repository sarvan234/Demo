package primark.esb.jtest.demo.java;

public interface Connector {
	void proceed();

	String getId();

	String getType();
	
	String getName();
}
