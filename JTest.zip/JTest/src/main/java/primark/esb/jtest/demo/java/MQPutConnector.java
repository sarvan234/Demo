package primark.esb.jtest.demo.java;

import static primark.esb.jtest.demo.java.ConfigurationHolder.configuration;

import java.io.File;

import primark.esb.jtest.demo.java.WriteConnector;
import primark.esb.jtest.demo.java.ConnectorException;
import primark.esb.jtest.demo.java.Constants;
import primark.esb.jtest.demo.java.PayloadReplacer;
import primark.esb.jtest.demo.java.FileUtils;

public class MQPutConnector extends MQAccessor implements WriteConnector {

	private final String name;

	/*public MQConnectorIn(String qManager, String qName, int port, String channelname, String hostname, String name) {
		super(qManager, qName, port, channelname, hostname);
		this.name = name;
		
	}
	*/
	
	public MQPutConnector(String qName, String name) {
		
		super(  
				configuration().getString(Constants.MQMANAGER_NAME_KEY),
				qName, 
				configuration().getInt(Constants.MQMANAGER_PORT_KEY),
				configuration().getString(Constants.MQMANAGER_CHANNEL_KEY),
				configuration().getString(Constants.MQMANAGER_HOST_KEY), 
				configuration().getString(Constants.MQMANAGER_USR_KEY),
				configuration().getString(Constants.MQMANAGER_PWD_KEY)
				);
		/*super(  
				configuration().getString("QDT1BRK2"),
				qName, 
				configuration().getInt("7005"),
				configuration().getString("QDT1BRK2.ADM.SVRCONN"),
				configuration().getString("10.150.21.43"), 
				configuration().getString("mqm"),
				configuration().getString(" ")
				);*/
		
		this.name = name;
	}

	@Override
	public void proceed() {
//		LOGGER.info("Proceed MQPutConnector [" + this.getQName() + "] message size " + message.length() + " / id: " + messageId);
		LOGGER.info("Proceed MQPutConnector [" + this.getQName() + "] message size " + message.length + " / id: " + messageId);
		if (null != message) {
			putMessage(message, messageId);
		}
	}

	public String getName() {
		return name;
	}
	


	@Override
	public void setRequest(File file) {
		PayloadReplacer.interpolate(file);
		this.message = FileUtils.getContents(file);

	}
	public String getId() {
		return  getType() + getQName() ;
	}
	
	public String getType() {
		return Constants.Connectors.MQPUT.toString();
	}


	@Override
	public void setRequest(String request) {

		LOGGER.error("set method is not allowed");
		throw new ConnectorException(new RuntimeException("set method is not allowed"));

	}

	
	

}
