package primark.esb.jtest.demo.java;

import static primark.esb.jtest.demo.java.ConfigurationHolder.configuration;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import primark.esb.jtest.demo.java.MQHeader;
import primark.esb.jtest.demo.java.Settings;

public class SettingsHolder {

	private SettingsHolder() {
	}

	private static Map<String, Settings> cache = new ConcurrentHashMap<>();

	static {
		cache.put(Constants.DEFAULT_MQGET, new MQHeader());
		cache.put(Constants.DEFAULT_MQPUT, new MQHeader());
	}

	public static Map<String, Settings> cache() {
		return cache;
	}

	public static Settings cacheByConnector(String type, String connector) {
		String connectorName = connector;
		String env = configuration().getString(Constants.ENV_IDX_KEY);

		if (null != connectorName) {
			connectorName = connectorName.replaceAll(env, Constants.ENV);
		}
		return cache.get(type + connectorName) !=null ? cache.get(type + connectorName): cache.get(Constants.DEFAULT_CONNECTOR_NAME + type);
	}
}
