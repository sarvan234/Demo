package primark.esb.jtest.demo.java;

public interface Settings {


	public String getType();
	
	//Settings setMessageFormat(String messageFormat);
	
	

}
