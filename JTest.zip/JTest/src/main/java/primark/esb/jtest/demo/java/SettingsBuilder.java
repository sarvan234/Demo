package primark.esb.jtest.demo.java;

public class SettingsBuilder  {

	
	public static MQHeader addMQHeader() {
		return new MQHeader();
	}
	

}
