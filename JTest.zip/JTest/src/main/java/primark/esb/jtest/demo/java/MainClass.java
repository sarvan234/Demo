package primark.esb.jtest.demo.java;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class MainClass {
	static final Logger logger = Logger.getLogger(MainClass.class);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
		logger.debug("Hello World!");
		String msg;
		FileGetConnector fileCon = new FileGetConnector("FILEGET@FileGetConnector");
		fileCon.proceed();
		msg = fileCon.getResponse();
		byte[] msgbytes = msg.getBytes();
		MQPutConnector MQPutCheck = new MQPutConnector("JTEST_IN_K", "Test");
		MQPutCheck.putMessage(msgbytes, "1");

	}
}
