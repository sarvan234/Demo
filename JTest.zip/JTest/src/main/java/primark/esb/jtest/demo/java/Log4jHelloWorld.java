package primark.esb.jtest.demo.java;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
public class Log4jHelloWorld {
	 static final Logger logger = Logger.getLogger(Log4jHelloWorld.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BasicConfigurator.configure();
        logger.debug("Hello World!");
	}

}
