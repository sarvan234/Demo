package primark.esb.jtest.demo.java;

public interface ReadConnector extends Connector {

	String getResponse();

	void setReponse(String response);
}
