package primark.esb.jtest.demo.java;

import java.util.List;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;

import com.google.common.collect.ImmutableList;
import primark.esb.jtest.demo.java.GenericException;

public class ConfigurationHolder extends PropertiesConfiguration {

	public static final Logger LOGGER = Logger.getLogger(ConfigurationHolder.class.getName());

	private static ConfigurationHolder configuration;

	private ConfigurationHolder(String confName) throws ConfigurationException {
		super(confName);
	}

	public static ConfigurationHolder configuration() {
		return configuration;
	}

	static {

		try {
			configuration = new ConfigurationHolder("config.properties");
			configuration.setThrowExceptionOnMissing(true);
			configuration.setIncludesAllowed(false);
			configuration.setListDelimiter(';');

		} catch (final ConfigurationException e) {

			LOGGER.error("can not initialize configuration ", e);
			throw new GenericException(e);

		}
		System.out.println(configuration);

		try {

			//PropertiesConfiguration configmq = new PropertiesConfiguration("config.mq.properties");

			/*
			 * for (String key : genericMqConfiguration () ) { if
			 * (configuration.containsKey(key)) { LOGGER.fatal(
			 * " Please remove all generic mq configuration " +
			 * Joiner.on(',').join(genericMqConfiguration()) +
			 * " from the \"config.properties\" in order to get the generated \"mq.properties\" working "
			 * ); throw new FatalConfigurationException(
			 * "Please remove all generic mq configuration " +
			 * Joiner.on(',').join(genericMqConfiguration()) +
			 * " from the \"config.properties\" in order to get the generated \"mq.properties\" working"
			 * ); //NOSONAR } }
			 */
			ConfigurationHolder configmq = new ConfigurationHolder("config.mq.properties");

			System.out.println(configmq);
			System.out.println(genericMqConfiguration());
			System.out.println(configuration);
			configuration.append(configmq);
			System.out.println(configuration);

		} catch (final ConfigurationException e) { // NOSONAR
			LOGGER.info("No generated mq.properties found ");
		}
	}

	public static List<String> genericMqConfiguration() {

		return ImmutableList.of(Constants.ENV_IDX_KEY, Constants.MQMANAGER_CHANNEL_KEY, Constants.MQOUT_KEY,
				Constants.MQMANAGER_HOST_KEY, Constants.MQMANAGER_PORT_KEY, Constants.MQMANAGER_NAME_KEY);
	}

	@Override
	public int getInt(String key) {
		return super.getInt(key.replace('@', '.'));

	}

	@Override
	public String getString(String key, String defValue) {
		return super.getString(key.replace('@', '.'), defValue);

	}

	@Override
	public String getString(String key) {
		return super.getString(key.replace('@', '.'));

	}

	@Override
	public List<Object> getList(String key) {
		super.getString(key.replace('@', '.'));// to get Exception if not exists
		return super.getList(key.replace('@', '.'));
	}
}
